import pandas as pd
import numpy as np

# datapath = r"C:\Users\kashir\Documents\python_scripts\ibkr\data\"
# print(datapath)




