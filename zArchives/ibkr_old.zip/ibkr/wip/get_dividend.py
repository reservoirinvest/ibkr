import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

dividend_url = "https://www.google.com/search?q=NSE:"
symbol = 'ICICI'
div_url = dividend_url + symbol


def get_dividend(div_url):
    """Returns the dividend as a float"""

    page = requests.get(div_url)

    root = LH.fromstring(page.content)

    try:
        dividend = float(root.findall('.//table')[2].text_content().strip().split("\n")[2].split('/')[0]) / 100
    except Exception as e:
        dividend = {'dividend': np.nan}
        return dividend

    dividend = {'dividend': dividend}

    return dividend

get_dividend(div_url)
